package edu.buet.messages;

import java.util.List;

import edu.buet.data.Movie;
//import edu.buet.data.Player;

public class TransferListResponse extends MessageBase<List<Movie>> {
    public TransferListResponse(boolean success, String message, List<Movie> body) {
        super(success, message, body);
    }
    public static TransferListResponse errorMessage(String reason) {
        return new TransferListResponse(false, reason, null);
    }
    public static TransferListResponse successMessage(List<Movie> transfers) {
        return new TransferListResponse(true, null, transfers);
    }
}
