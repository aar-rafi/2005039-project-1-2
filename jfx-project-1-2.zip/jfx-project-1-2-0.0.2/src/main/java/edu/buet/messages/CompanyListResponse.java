package edu.buet.messages;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

//import edu.buet.data.Club;
import edu.buet.data.Company;

public class CompanyListResponse extends MessageBase<List<CompanyEntry>> {
    CompanyListResponse(boolean success, String message, List<CompanyEntry> value) {
        super(success, message, value);
    }
    public static CompanyListResponse errorMessage(String reason){
        return new CompanyListResponse(false, reason, null);
    }
    public static CompanyListResponse successMessage(Collection<Company> clubs){
        var r = new ArrayList<CompanyEntry>(clubs.size());
        for(var club : clubs){
            r.add(new CompanyEntry(club.getId(), club.getCompanyName(), club.getAltName()));
            //System.out.println(club.getCompanyName());
        }

        return new CompanyListResponse(true, null, r);
    }
}
