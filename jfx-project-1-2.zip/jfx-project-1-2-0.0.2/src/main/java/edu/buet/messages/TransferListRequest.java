package edu.buet.messages;

public class TransferListRequest extends MessageBase<Void> {
}
