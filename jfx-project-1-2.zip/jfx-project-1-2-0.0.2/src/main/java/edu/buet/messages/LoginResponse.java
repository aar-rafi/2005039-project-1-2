package edu.buet.messages;

//import edu.buet.data.Club;
import edu.buet.data.Company;

public class LoginResponse extends MessageBase<Company>{
    private LoginResponse(boolean success, String message, Company body){
        super(success, message, body);
    }
    public static LoginResponse errorMessage(String reason){
        return new LoginResponse(false, reason, null);
    }
    public static LoginResponse successMessage(Company club){
        return new LoginResponse(true, null, club);
    }
}
