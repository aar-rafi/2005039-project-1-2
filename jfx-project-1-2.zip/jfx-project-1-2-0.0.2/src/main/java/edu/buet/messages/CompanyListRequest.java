package edu.buet.messages;
public class CompanyListRequest extends MessageBase<Void> {
}
