package edu.buet.messages;
public class ClubListRequest extends MessageBase<Void> {
}
