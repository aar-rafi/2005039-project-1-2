package edu.buet.messages;
import java.io.Serializable;
public class CompanyEntry implements Serializable {
    public final int id;
    public final String name;
    public final String altName;
    CompanyEntry(int id, String name, String altName) {
        this.id = id;
        this.name = name;
        this.altName = altName;
    }
}
