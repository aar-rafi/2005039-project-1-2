package edu.buet.messages;

public class LogoutRequest extends MessageBase<Void>{
}
