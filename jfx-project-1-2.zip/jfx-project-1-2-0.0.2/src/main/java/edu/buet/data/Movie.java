package edu.buet.data;


import javafx.beans.binding.StringBinding;

import java.io.Serializable;
import java.util.Map;

public class Movie implements Serializable {
    private int id;
    private String title;
    private final String altTitle;
    private int yearofRelease;
    private String[] genre = new String[3];
    private int runningTime;
    private String productionCompany;
private String url;
private TransferOffer transferOffer;

    private Company company;
    private Currency budget;
    private Currency revenue;

//    public Movie(String[] parameters){
//        int i=0;
//        this.title = parameters[i++];
//        this.yearofRelease = Integer.parseInt(parameters[i++]);
//        for(int j=0;;) {
//            boolean num=parameters[i].matches("-?\\d+(\\.\\d+)?");
//            if(num) break;
//            else this.genre[j++] = parameters[i++];
//        }
//        this.runningTime = Integer.parseInt(parameters[i++]);
//        this.productionCompany = parameters[i++];
//        this.budget = Long.parseLong(parameters[i++]);
//        this.revenue = Long.parseLong(parameters[i]);
//
//    }
    public Movie(String line, Map<String,Company> map){//
        var props = line.strip().split(",");
        this.id=Integer.parseInt(props[0]);
        this.title = props[1];
        this.altTitle=props[1];
        this.yearofRelease = Integer.parseInt(props[2]);
        this.genre[0] = props[3];
        this.genre[1] = props[4];
        this.genre[2] = props[5];
        this.runningTime = Integer.parseInt(props[6]);
        this.productionCompany= props[7];
        this.budget = new Currency(props[8]);
        this.revenue = new Currency(props[9]);
        this.url=props[10];
        this.transferOffer=null;
        this.company=(map.get(productionCompany));
        //this.players = new ArrayList<>();
    }
@Override
    public String toString(){
        var wh=new StringBuilder();
        wh.append(id);
        wh.append(",");
        wh.append(title);
        wh.append(",");
        wh.append(yearofRelease);
        wh.append(",");
        wh.append(genre[0]);
        wh.append(",");
        wh.append(genre[1]);
        wh.append(",");
        wh.append(genre[2]);
        wh.append(",");
        wh.append(runningTime);
        wh.append(",");
        wh.append(productionCompany);
        wh.append(",");
        wh.append(budget.getString());
        wh.append(",");
        wh.append(revenue.getString());
        wh.append(",");
        wh.append(url);

        return toString();
    }
    public String getTitle() {
        return title;
    }

    public int getYearofRelease() {
        return yearofRelease;
    }

    public String[] getGenre() {
        return genre;
    }
    public String getGenre1(){
        return genre[0];
    }
    public String getGenre2(){
        return genre[1];
    }
    public String getGenre3(){
        return genre[2];
    }

    public Currency getBudget() {
        return budget;
    }

    public Currency getRevenue() {
        return revenue;
    }

    public int getRunningTime() {
        return runningTime;
    }
    public Company getCompany() {
        return company;
    }
    public String getProductionCompany() {
        return productionCompany;
    }
    public void printInfo(){
        System.out.print(title+"," + yearofRelease +"," );

        for(String s: genre) {
            if(s.matches("null"))
                System.out.print("");
            else System.out.print(s+",");
        }
        System.out.println(runningTime +"," + productionCompany +"," +budget+"," +revenue);
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public TransferOffer getTransfer() {
        return transferOffer;
    }

    public void setTransfer(TransferOffer transferOffer) {
        System.out.println("tranfer  "+this.title);
        this.transferOffer = transferOffer;
    }

    public void setProductionCompany(Company productionCompany) {
        this.company = productionCompany;
    }
    final public boolean hasTransfer() {
        return transferOffer != null;
    }

    public String getAltTitle() {
        return altTitle;
    }
//    public Company getProductionCompany() {
//        return company;
//    }
}


