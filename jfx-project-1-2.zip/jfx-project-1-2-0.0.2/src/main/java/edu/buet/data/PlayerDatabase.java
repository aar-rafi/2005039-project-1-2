package edu.buet.data;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

public class PlayerDatabase {
    private static final Charset cs = Charset.forName("UTF-8");
    private Map<Integer, Movie> movieMap;
    private Map<Integer, Company> companyMap;
    private Map<Integer, TransferOffer> transfers;
    private Map<String ,Company> extra;
    private PlayerDatabase() {
        movieMap = new ConcurrentHashMap<>();
        extra = new ConcurrentHashMap<>();
        companyMap = new ConcurrentHashMap<>();
        transfers = new ConcurrentHashMap<>();
    }
    public static PlayerDatabase parseFile(String dir) throws IOException {
        var db = new PlayerDatabase();
        var fs = FileSystems.getDefault();
//        for (var line : Files.readAllLines(fs.getPath(dir, "countries.txt"), cs)) {
//            var c = new Country(line);
//            db.countries.put(c.getId(), c);
//        }
        for (var line : Files.readAllLines(fs.getPath(dir, "Company.txt"), cs)) {
            var c = new Company(line);
            db.companyMap.put(c.getId(), c);
            db.extra.put(c.getCompanyName(),c);
            //System.out.println(db.companyMap.get(c.getId()).getCompanyName());
        }
        for (var line : Files.readAllLines(fs.getPath(dir, "copies.txt"), cs)) {
            //var p = new Player(line, db.companyMap, db.countries);
            var p =new Movie(line,db.extra);
            //p.printInfo();
            var c = p.getCompany();
            //db.companyMap.put(p.getId(),c);
            if (c != null) c.addMovies(p);
            db.movieMap.put(p.getId(), p);

        }
        try {
            for (var line : Files.readAllLines(fs.getPath(dir, "transfers.txt"), cs)) {
                var t = new TransferOffer(line);
                db.movieMap.get(t.getPlayerId()).setTransfer(t);
                db.transfers.put(t.getPlayerId(), t);
            }
        } catch (IOException e) { //file may not exist
        }
        return db;
    }
    public synchronized void writeToFile(String dir) {
        var fs = FileSystems.getDefault();
        try {
            System.out.println("aa");
            Files.write(fs.getPath(dir, "clubs.txt"), companyMap.values().stream().map(Company::toString).collect(Collectors.toList()), cs);
            System.out.println("aa");
            Files.write(fs.getPath(dir, "players.txt"), movieMap.values().stream().map(c -> c.toString()).collect(Collectors.toList()), cs);
            Files.write(fs.getPath(dir, "transfers.txt"), transfers.values().stream().map(c -> c.toString()).collect(Collectors.toList()), cs);
            System.out.println("aa");
        } catch (Exception e) {
            System.out.println("jijiji"+e);
        }
    }
    public synchronized Movie getPlayer(int id) {
        return movieMap.get(id);
    }
    public synchronized Company getClub(int id) {
        return this.companyMap.get(id);
    }
    public synchronized List<Company> getCompanyMap() {
        return companyMap.values().stream().collect(Collectors.toList());
    }
    public synchronized List<Movie> getTransfers() {
        return transfers.values().stream().map(t -> movieMap.get(t.getPlayerId())).collect(Collectors.toList());
    }
    public synchronized TransferOffer getTransferOffer(int playerId) {
        return transfers.get(playerId);
    }
    public synchronized boolean hasTransferOffer(int playerId) {
        return getTransferOffer(playerId) != null;
    }
    public TransferOffer createTransferOffer(int playerId, int sellingClub, float fee) {
        return new TransferOffer(playerId, sellingClub, new Currency(fee));
    }
    public synchronized TransferOffer addTransferOffer(TransferOffer offer) {
        movieMap.get(offer.getPlayerId()).setTransfer(offer);
        return transfers.put(offer.getPlayerId(), offer);
    }
    public synchronized TransferOffer removeTransferOffer(int playerId) {
        movieMap.get(playerId).setTransfer(null);
        return transfers.remove(playerId);
    }
}
