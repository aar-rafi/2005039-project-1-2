package edu.buet.data;


import java.io.Serializable;
import java.util.ArrayList;
//import java.util.Currency;
import java.util.List;

public class Company implements Serializable {
    private final int id;
    private final String companyName;
    private final String altName;

    private final Currency profit;
    private final List<Movie> movies;


    public Company(String line){
        var props = line.strip().split(";");
        this.id=Integer.parseInt(props[0]);
        this.companyName=props[1];
        this.altName=props[2];
        this.profit =new Currency(props[3]);
        movies = new ArrayList<>();
    }


    public String toString(){
        var wh= new StringBuilder();
        wh.append(id);
        wh.append(";");
        wh.append(companyName);
        wh.append(";");
        wh.append(altName);
        wh.append(";");
        wh.append(profit.getString());

        return toString();
    }
    public void addMovies(Movie m){
       movies.add(m);
       //m.printInfo();
    }
    final public List<Movie> getMovies(){return this.movies;}
    final public void removeMovies(Movie m){
        movies.remove(m);
    }
    public Currency getProfit() {
        return profit;
    }

    public String getCompanyName() {
        return companyName;
    }

    public int getId() {
        return id;
    }

    public String getAltName() {
        return altName;
    }
}

