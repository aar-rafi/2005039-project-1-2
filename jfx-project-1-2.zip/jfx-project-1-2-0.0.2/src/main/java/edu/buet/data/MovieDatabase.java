package edu.buet.data;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

public class MovieDatabase {
    private static final Charset cs = Charset.forName("UTF-8");
    private Map<Integer, Movie> movieMap;
    private Map<Integer, Company> companyMap;
    private Map<Integer, TransferOffer> transfers;
    private Map<String ,Company> extra;
    private MovieDatabase() {
        movieMap = new ConcurrentHashMap<>();
        extra = new ConcurrentHashMap<>();
        companyMap = new ConcurrentHashMap<>();
        transfers = new ConcurrentHashMap<>();
    }
    public static MovieDatabase parseFile(String dir) throws IOException {
        var db = new MovieDatabase();
        var fs = FileSystems.getDefault();
//        for (var line : Files.readAllLines(fs.getPath(dir, "countries.txt"), cs)) {
//            var c = new Country(line);
//            db.countries.put(c.getId(), c);
//        }
        for (var line : Files.readAllLines(fs.getPath(dir, "company1.txt"), cs)) {
            var c = new Company(line);
            db.companyMap.put(c.getId(), c);
            db.extra.put(c.getCompanyName(),c);
            //System.out.println(db.companyMap.get(c.getId()).getCompanyName());
        }
        for (var line : Files.readAllLines(fs.getPath(dir, "movies.txt"), cs)) {
            //var p = new Player(line, db.companyMap, db.countries);
            var p =new Movie(line,db.extra);
            //p.printInfo();
            var c = p.getCompany();
            //db.companyMap.put(p.getId(),c);
            if (c != null) c.addMovies(p);
            db.movieMap.put(p.getId(), p);

        }
        try {
            for (var line : Files.readAllLines(fs.getPath(dir, "transfer1.txt"), cs)) {
                var t = new TransferOffer(line);
                db.movieMap.get(t.getPlayerId()).setTransfer(t);
                db.transfers.put(t.getPlayerId(), t);
            }
        } catch (IOException e) { //file may not exist
        }
        return db;
    }
    public synchronized void writeToFile(String dir) {
        //var fs = FileSystems.getDefault();

        try {BufferedWriter bw=new BufferedWriter(new FileWriter(dir+"/movies.txt"));
            BufferedWriter bw1=new BufferedWriter(new FileWriter(dir+"/company1.txt"));
            BufferedWriter bw2=new BufferedWriter(new FileWriter(dir+"/transfer1.txt"));
            //System.out.println("aa");
            //System.out.println(movieMap.size());
            for(var v:movieMap.keySet()){
           //System.out.println(movieMap.get(v).getTitle());
            bw.write(movieMap.get(v).getId()+","+movieMap.get(v).getTitle()+"," +movieMap.get(v).getYearofRelease() + "," +
                    movieMap.get(v).getGenre1() + "," + movieMap.get(v).getGenre2() + "," + movieMap.get(v).getGenre3() + "," +
                    movieMap.get(v).getRunningTime() + "," +
                    movieMap.get(v).getProductionCompany() + "," +
                    movieMap.get(v).getBudget().getString() + "," +
                    movieMap.get(v).getRevenue().getString()+","+movieMap.get(v).getUrl());
                bw.write(System.lineSeparator());
            }bw.close();
            for(var v:companyMap.keySet()){
                //System.out.println(companyMap.get(v).getTitle());
                bw1.write(companyMap.get(v).getId()+";"+companyMap.get(v).getCompanyName()+";" +companyMap.get(v).getAltName() + ";" +
                        companyMap.get(v).getProfit().getString() );
                bw1.write(System.lineSeparator());
            }bw1.close();
            for(var v:transfers.keySet()){
                //System.out.println(transfers.get(v).getTitle());
                bw2.write(transfers.get(v).getPlayerId()+";"+transfers.get(v).getSellingClubId()+";" +transfers.get(v).getFee().getString());
                bw2.write(System.lineSeparator());
            }bw2.close();
//            Files.write(fs.getPath(dir, "clubs.txt"), companyMap.values().stream().map(Company::toString).collect(Collectors.toList()), cs);
//            System.out.println("aa");
//            Files.write(fs.getPath(dir, "players.txt"), movieMap.values().stream().map(c -> c.toString()).collect(Collectors.toList()), cs);
//            Files.write(fs.getPath(dir, "transfers.txt"), transfers.values().stream().map(c -> c.toString()).collect(Collectors.toList()), cs);
//            System.out.println("aa");
        } catch (Exception e) {
            System.out.println("jijiji"+e);
        }
    }
    public synchronized Movie getPlayer(int id) {
        return movieMap.get(id);
    }
    public synchronized Company getClub(int id) {
        return this.companyMap.get(id);
    }
    public synchronized List<Company> getCompanyMap() {
        return companyMap.values().stream().collect(Collectors.toList());
    }
    public synchronized List<Movie> getTransfers() {
        return transfers.values().stream().map(t -> movieMap.get(t.getPlayerId())).collect(Collectors.toList());
    }
    public synchronized TransferOffer getTransferOffer(int playerId) {
        return transfers.get(playerId);
    }
    public synchronized boolean hasTransferOffer(int playerId) {
        return getTransferOffer(playerId) != null;
    }
    public TransferOffer createTransferOffer(int playerId, int sellingClub, float fee) {
        return new TransferOffer(playerId, sellingClub, new Currency(fee));
    }
    public synchronized TransferOffer addTransferOffer(TransferOffer offer) {
        movieMap.get(offer.getPlayerId()).setTransfer(offer);
        return transfers.put(offer.getPlayerId(), offer);
    }
    public synchronized TransferOffer removeTransferOffer(int playerId) {
        movieMap.get(playerId).setTransfer(null);
        return transfers.remove(playerId);
    }
}
