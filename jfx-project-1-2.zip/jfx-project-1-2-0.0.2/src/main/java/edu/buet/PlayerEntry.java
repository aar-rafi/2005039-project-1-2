package edu.buet;

import java.io.IOException;

//import edu.buet.data.Player;
import edu.buet.data.Movie;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;

public class PlayerEntry extends HBox {
    @FXML
    private Label movieNumber;
    @FXML
    private Label name;
    @FXML
    private Label genre1;
    @FXML
    private Label budget;
    @FXML
    private Label year;
    @FXML
    private Label time;
    @FXML
    private Label salaryOrFee;
    @FXML
    private ImageView movieImageView;

    @FXML
    private Button sellOrBuyButton;
    @FXML
    private Button infoButton;

    private Image playerImage;
    private Movie player;
private static int i=1;
    public PlayerEntry(Movie player) {
        this.player = player;
        FXMLLoader fxmlLoader = new FXMLLoader(App.class.getResource("playerentry.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);
        try {
            fxmlLoader.load();
        } catch (IOException exception) {
            throw new RuntimeException(exception);
        }
    }
    @FXML
    void initialize() {
        movieNumber.setText(i+ "");
        i++;
        name.setText(player.getTitle());
        genre1.setText(player.getGenre1());
        budget.setText(String.valueOf(player.getBudget().getNumber()));
        year.setText(player.getYearofRelease() + "");
        time.setText(player.getRunningTime() + " min");
        salaryOrFee.setText(player.getRevenue().getString());
        movieImageView.setCache(true);
        movieImageView.setSmooth(false);
        //flagImageView.setCache(true);
        //flagImageView.setSmooth(false);
        playerImage = new Image(player.getUrl(), true);
        //flagImage = new Image(player.getCountry().getFlagUrl(), true);
        movieImageView.setImage(playerImage);
        //flagImageView.setImage(flagImage);
    }
    Button sellOrBuyButton() {
        return sellOrBuyButton;
    }
    Button infoButton() {
        return infoButton;
    }
    public Movie getPlayer() {
        return player;
    }
    Image getPlayerImage() {
        return playerImage;
    }
//    Image getFlagImage() {
//        return flagImage;
//    }
    @Override
    public boolean equals(Object other) {
        if(other instanceof PlayerEntry)
            return player.getId() == ((PlayerEntry)other).getPlayer().getId();
        return false;
    }
}
