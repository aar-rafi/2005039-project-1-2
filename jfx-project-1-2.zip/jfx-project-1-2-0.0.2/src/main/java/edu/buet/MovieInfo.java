package edu.buet;

import java.io.IOException;

//import edu.buet.data.Club;
import edu.buet.data.Company;
import edu.buet.data.Currency;
import edu.buet.data.Movie;
//import edu.buet.data.Player;
import edu.buet.data.TransferOffer;
import edu.buet.messages.TransferOfferRequest;
import edu.buet.messages.TransferOfferResponse;
import edu.buet.messages.TransferRequest;
import edu.buet.messages.TransferResponse;
import javafx.application.Platform;
import javafx.beans.property.ObjectProperty;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Spinner;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;

public class MovieInfo extends VBox {
    @FXML
    private Label name;
    @FXML
    private Label company;
    @FXML
    private Label year;
    @FXML
    private Label time;
//    @FXML
//    private Label weight;
//    @FXML
//    private Label movieNumber;
//    @FXML
//    private Label preferredFoot;
    @FXML
    private Label genre1;
    @FXML
    private Label genre2;
    @FXML
    private Label genre3;
    @FXML
    private Label revenue;
    @FXML
    private Label budget;
    @FXML
    private ImageView imageView;
    @FXML
    private ImageView flagView;
    @FXML
    private Button sellOrConfirmButton;
    @FXML
    private Button backButton;
    @FXML
    private Spinner<Double> feeSpinner;
    @FXML
    private HBox transferInfo;
    @FXML
    private HBox transferBox;
    @FXML
    private Label transferFee;
    @FXML
    private VBox body;
    @FXML
    private Pane ipane;
    private Label[] genres = new Label[3];

    private Movie player;
    private Company club;
    private MovieEntry entry;

    private BottomBar bottomBar;

    private boolean transferPrompt;

    public MovieInfo(Company club, MovieEntry entry, boolean transferPrompt) {
        this.club = club;
        this.transferPrompt = transferPrompt;
        this.entry = entry;
        this.player = entry.getPlayer();
        FXMLLoader fxmlLoader = new FXMLLoader(App.class.getResource("movieinfo.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);
        VBox.setVgrow(this, Priority.ALWAYS);
        try {
            fxmlLoader.load();
        } catch (IOException exception) {
            throw new RuntimeException(exception);
        }
    }

    ObjectProperty<EventHandler<? super MouseEvent>> backButtonClickedProperty() {
        return backButton.onMouseClickedProperty();
    }

    @FXML
    void initialize() {
        bottomBar = new BottomBar();
        genres[0] = genre1;
        genres[1] = genre2;
        genres[2] = genre3;
        name.setText(player.getTitle());
        company.setText(player.getCompany().getCompanyName());
        year.setText(player.getYearofRelease() + "");
        time.setText(player.getRunningTime() + " cm");
//        weight.setText(player.getWeight() + " kg");
//        movieNumber.setText(Integer.toString(player.getJerseyNumber()));
//        preferredFoot.setText(player.getPreferredFoot().toString());
        var positions = player.getGenre();
        for (int i = 0; i < 3; i++) {
            if ( positions[i].length()>1) {
                genres[i].setText(positions[i]);
            } else {
                genres[i].setText("");
            }
        }
        name.setText(player.getTitle());
        imageView.setSmooth(true);
        imageView.setPreserveRatio(true);
//        flagView.setSmooth(false);
        imageView.setCache(true);
//        flagView.setCache(true);
        imageView.setImage(entry.getPlayerImage());
        ipane.setCenterShape(true);
        //flagView.setImage(entry.getFlagImage());
        if (player.hasTransfer()) {
            transferBox.setVisible(false);
            transferInfo.setVisible(true);
            transferFee.setText(player.getTransfer().getFee().getString());
            if (player.getTransfer().getSellingClubId() == club.getId()) {
                sellOrConfirmButton.setVisible(false);
            } else {
                if (!transferPrompt) {
                    sellOrConfirmButton.setText("Buy");
                } else {
                    sellOrConfirmButton.setText("Confirm");
                }
                sellOrConfirmButton.setVisible(true);
            }
        } else {
            transferInfo.setVisible(false);
            sellOrConfirmButton.setVisible(true);
            if (!transferPrompt) {
                sellOrConfirmButton.setText("Sell");
                transferBox.setVisible(false);
            } else {
                sellOrConfirmButton.setText("Confirm");
                transferBox.setVisible(true);
            }
        }
        sellOrConfirmButton.onActionProperty().set( e -> {
            if (transferPrompt) {
                if (player.hasTransfer()) { //buy
                    if (club.getProfit().getNumber() > player.getTransfer().getFee().getNumber()) {
                        if (player.getTransfer().getSellingClubId() != club.getId()) {
                            App.connect().thenAccept( s -> {
                                s.sendNow(new TransferRequest(player.getId()), TransferResponse.class)
                                .thenAccept( res -> {
                                    Platform.runLater(()->{
                                        if (res.success()) {
                                            transferBox.setVisible(false);
                                            sellOrConfirmButton.setVisible(false);
                                            transferInfo.setVisible(false);
                                        } else {
                                            bottomBar.setMessage(BottomBar.Type.ERROR, res.getMessage());
                                            bottomBar.show(body);
                                        }
                                    });
                                });
                            });
                        }
                    } else {
                        bottomBar.setMessage(BottomBar.Type.WARNING, "Not enough budget");
                        bottomBar.show(body);
                    }
                } else { //sell
                    var fee = (float)(double)feeSpinner.getValue();
                    App.connect().thenAccept( s -> {
                        s.sendNow(new TransferOfferRequest(player.getId(), fee), TransferOfferResponse.class)
                        .thenAccept( res -> {
                            Platform.runLater(()->{
                                if (res.success()) {
                                    var cf = new Currency(fee);
                                    transferBox.setVisible(false);
                                    sellOrConfirmButton.setVisible(false);
                                    transferInfo.setVisible(true);
                                    transferFee.setText(cf.getString());
                                    entry.sellOrBuyButton().setVisible(false);
                                    player.setTransfer(new TransferOffer(player.getId(), club.getId(), cf));
                                } else {
                                    bottomBar.setMessage(BottomBar.Type.ERROR, res.getMessage());
                                    bottomBar.show(body);
                                }
                            });
                        });
                    });
                }
            } else {
                transferPrompt = true;
                sellOrConfirmButton.setText("Confirm");
                if (!player.hasTransfer())
                    transferBox.setVisible(true);
            }
        });
    }
}
